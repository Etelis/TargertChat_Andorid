package com.example.targertchat.data.remote;

import com.example.targertchat.data.model.Contact;
import com.example.targertchat.data.utils.ContactResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface IContactsApi {
    @GET("Contacts")
    Call<List<Contact>> getContacts();

    @POST("Contacts")
    Call<Void> addContact(@Body ContactResponse contactResponse);

    @GET("Contacts/{id}")
    Call<Contact> getContactByID(@Path("id") String contactID);

}
