package com.example.targertchat.data.utils;

public class RegisterResponse {

}
