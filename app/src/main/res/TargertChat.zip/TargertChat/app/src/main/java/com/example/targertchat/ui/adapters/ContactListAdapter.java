package com.example.targertchat.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.targertchat.R;
import com.example.targertchat.data.model.Contact;

import java.util.List;

public class ContactListAdapter extends RecyclerView.Adapter<ContactListAdapter.ContactViewHolder> {
    class ContactViewHolder extends RecyclerView.ViewHolder{
        private final TextView tvTitle;
        private final TextView tvDetails;
        private final ImageView imageView;

        private ContactViewHolder(View itemView){
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDetails = itemView.findViewById(R.id.tv_detail);
            imageView = itemView.findViewById(R.id.img_icon);
        }
    }

    private final LayoutInflater mInflater;
    private List<Contact> contacts;

    public ContactListAdapter(Context context){
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.contact_layout, parent, false);
        return new ContactViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ContactViewHolder holder, int position) {
        if (contacts != null) {
            final Contact current = contacts.get(position);
            holder.tvTitle.setText(current.getContactName());
            holder.tvDetails.setText(current.getLastMessage());
        }
    }

    public void setContacts(List<Contact> s){
        contacts = s;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount(){
        if(contacts != null)
            return contacts.size();
        else return 0;
    }

    public List<Contact> getContacts() {return contacts;}

}
