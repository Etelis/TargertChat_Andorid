package com.example.targertchat.data.utils;

public class PostLoginUser {
    private String userName;
    private String password;

    public PostLoginUser(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
}
