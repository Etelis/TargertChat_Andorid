package com.example.targertchat.data.model;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Contact.class, Message.class}, version = 1)
public abstract class LocalDatabase extends RoomDatabase{
    public abstract IContactDao contactDao();
    public abstract IMessageDao messageDao();
}
