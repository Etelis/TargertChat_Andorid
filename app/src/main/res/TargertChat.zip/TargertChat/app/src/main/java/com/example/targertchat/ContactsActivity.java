package com.example.targertchat;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.targertchat.ui.adapters.ContactListAdapter;
import com.example.targertchat.ui.contacts.ContactsViewModel;
import com.example.targertchat.ui.contacts.ContactsViewModelFactory;

public class ContactsActivity extends AppCompatActivity {

    private ContactsViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        viewModel = new ViewModelProvider
                (this, new ContactsViewModelFactory()).get(ContactsViewModel.class);


        RecyclerView listItems = findViewById(R.id.listItems);
        final ContactListAdapter adapter = new ContactListAdapter(this);
        listItems.setAdapter(adapter);
        listItems.setLayoutManager(new LinearLayoutManager(this));

        SwipeRefreshLayout refreshLayout = findViewById(R.id.refreshLayout);
        refreshLayout.setOnRefreshListener(() -> {
            viewModel.getContacts();
            });

        viewModel.getContacts().observe(this, contacts -> {
            adapter.setContacts(contacts);
            refreshLayout.setRefreshing(false);
            });
    }
}