package com.example.targertchat.data.repositories;

import androidx.lifecycle.MutableLiveData;

import com.example.targertchat.data.model.Contact;
import com.example.targertchat.data.remote.ContactsApiManager;
import com.example.targertchat.data.utils.ContactResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ContactsRepository {
    private static volatile ContactsRepository instance;
    private final ContactsApiManager contactsApiManager;
    private final MutableLiveData<List<Contact>> contacts = new MutableLiveData<>();
    private final MutableLiveData<Contact> contact = new MutableLiveData<>();


    private ContactsRepository(ContactsApiManager contactsApiManager) {
        this.contactsApiManager = ContactsApiManager.getInstance();
    }

    public static ContactsRepository getInstance(ContactsApiManager contactsApiManager) {
        if (instance == null) {
            instance = new ContactsRepository(contactsApiManager);
        }
        return instance;
    }

    public MutableLiveData<List<Contact>> getContacts(){
        this.contactsApiManager.getContacts(new Callback<List<Contact>>() {
            @Override
            public void onResponse(Call<List<Contact>> call, Response<List<Contact>> response) {
                if (response.isSuccessful()){
                    List<Contact> contactsList = response.body();
                    contacts.setValue(contactsList);
                } else{
                    contacts.postValue(null);
                }
            }

            @Override
            public void onFailure(Call<List<Contact>> call, Throwable t) {
                contacts.postValue(null);
            }
        });

        return contacts;
    }

    public MutableLiveData<Contact> getContactByID(String contactID){
        this.contactsApiManager.getContactByID(new Callback<Contact>() {
            @Override
            public void onResponse(Call<Contact> call, Response<Contact> response) {
                if (response.isSuccessful()){
                    Contact contactReceived = response.body();
                    contact.setValue(contactReceived);
                } else{
                    contact.postValue(null);
                }
            }

            @Override
            public void onFailure(Call<Contact> call, Throwable t) {
                contact.postValue(null);
            }
        }, contactID);

        return contact;
    }

    public void addContact (ContactResponse postContact){
        this.contactsApiManager.addContact(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (!response.isSuccessful()){
                    //TODO error
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                //TODO errors
            }
        }, postContact);
    }
}
