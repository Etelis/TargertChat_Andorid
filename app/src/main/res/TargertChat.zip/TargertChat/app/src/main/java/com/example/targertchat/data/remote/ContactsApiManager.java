package com.example.targertchat.data.remote;

import com.example.targertchat.data.model.Contact;
import com.example.targertchat.data.utils.ContactResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

public class ContactsApiManager {
    private static IContactsApi service;
    private static ContactsApiManager apiManager;

    private ContactsApiManager() {
        service = RetrofitService.CreateContactApi();
    }

    public static ContactsApiManager getInstance() {
        if (apiManager == null) {
            apiManager = new ContactsApiManager();
        }
        return apiManager;
    }

    public void getContacts(Callback<List<Contact>> callback){
        Call<List<Contact>> getContactsCall = service.getContacts();
        getContactsCall.enqueue(callback);
    }

    public void addContact(Callback<Void> callback, ContactResponse contactResponse){
        Call<Void> addContactCall = service.addContact(contactResponse);
        addContactCall.enqueue(callback);
    }

    public void getContactByID(Callback<Contact> callback, String id){
        Call<Contact> getContactByIDCall = service.getContactByID(id);
        getContactByIDCall.enqueue(callback);
    }
}
