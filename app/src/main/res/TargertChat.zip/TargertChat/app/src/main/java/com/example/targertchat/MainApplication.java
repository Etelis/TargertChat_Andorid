package com.example.targertchat;
import android.app.Application;

import com.example.targertchat.data.remote.ContactsApiManager;
import com.example.targertchat.data.remote.UsersApiManager;

public class MainApplication extends Application {

    public static UsersApiManager usersApiManager;
    public static ContactsApiManager contactsApiManager;

    @Override
    public void onCreate() {
        super.onCreate();
        usersApiManager = UsersApiManager.getInstance();
        contactsApiManager = ContactsApiManager.getInstance();
    }
}