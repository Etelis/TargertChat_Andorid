package com.example.targertchat.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Message {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String content;
    private String date;
    private boolean sent;

    public Message(int id, String content, String date, boolean sent) {
        this.id = id;
        this.content = content;
        this.date = date;
        this.sent = sent;
    }

    public int getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public String getDate() {
        return date;
    }

    public boolean isSent() {
        return sent;
    }

}
